from django.db import models

class Reporter(models.Model):
    full_name = models.CharField(max_length=200)

    def __str__(self):
        return self.full_name

class Article(models.Model):
    reporter = models.ForeignKey(Reporter, on_delete = models.CASCADE)
    pub_date = models.DateTimeField()
    headline = models.CharField(max_length=200)
    content = models.TextField()

    def __str__(self):
        return self.headline