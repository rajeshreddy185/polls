from django.shortcuts import render
from django.http import HttpResponse

from .models import Reporter,Article

def home(request):
    return HttpResponse('<h1> welcome to news page</h1>')


def year_archive(request, year):
    a_list = Article.objects.filter(pub_date__year=year)
    return render(request, 'news/year_archive.html', {'year': year, 'article_list': a_list})
